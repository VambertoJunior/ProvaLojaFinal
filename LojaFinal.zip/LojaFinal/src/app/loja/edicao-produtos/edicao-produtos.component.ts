import { Component } from '@angular/core';

@Component({
  selector: 'app-edicao-produtos',
  standalone: true,
  imports: [],
  templateUrl: './edicao-produtos.component.html',
  styleUrl: './edicao-produtos.component.css'
})
export class EdicaoProdutosComponent {

}
