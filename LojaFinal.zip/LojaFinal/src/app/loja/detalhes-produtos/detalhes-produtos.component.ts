import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProdutoService } from "../../shared/service/produto-service.service";
import { Produto } from "../../shared/modelo/produto";
import { Imagem } from "../../shared/modelo/imagem";

@Component({
  selector: 'app-detalhes-produtos',
  templateUrl: './detalhes-produtos.component.html',
  styleUrls: ['./detalhes-produtos.component.css']
})
export class DetalhesProdutosComponent implements OnInit {

  produtoSelecionado: Produto | null = null;

  constructor(private route: ActivatedRoute, private produtoService: ProdutoService) {
    this.produtoSelecionado
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const produtoId = Number(params['id']);
      this.carregarDetalhesProduto(produtoId);
    });
  }

  carregarDetalhesProduto(produtoId: number): void {
    this.produtoService.getDetalhesProduto(produtoId).subscribe(produto => {
      this.produtoSelecionado = produto;
    });
  }
    adicionarImagem(): void {
    if (this.produtoSelecionado && this.produtoSelecionado.id) {
        const novaImagem: Imagem = {
            id: 0,
            nome: 'Nova Imagem',
            url: 'caminho/para/a/nova-imagem.jpg',
            produto: this.produtoSelecionado
        };

        this.produtoService.adicionarImagemAoProduto(this.produtoSelecionado.id, novaImagem).subscribe(() => {
            if (this.produtoSelecionado && this.produtoSelecionado.id) {
                this.carregarDetalhesProduto(this.produtoSelecionado.id);
            }
        });
    }
  }
}
