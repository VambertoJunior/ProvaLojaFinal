import { Component, OnInit } from '@angular/core';
import { ProdutoService } from "../../shared/service/produto-service.service";
import {Produto} from "../../shared/modelo/produto";

@Component({
  selector: 'app-listagem-produtos',
  templateUrl: './listagem-produtos.component.html',
  styleUrls: ['./listagem-produtos.component.css']
})
export class ListagemProdutosComponent implements OnInit {

  produtos: Produto[] = [];
  novoProduto: Produto = { id: 0, nome: '', descricao: '', preco: 0, imagens: [] };

  constructor(private produtoService: ProdutoService) { }

  ngOnInit(): void {
    this.carregarProdutos();
  }

  carregarProdutos(): void {
    this.produtoService.getProdutos().subscribe(produtos => {
      this.produtos = produtos;
    });
  }

  // Adicionar produto
  adicionarProduto(novoProduto: Produto): void {
    this.produtoService.adicionarProduto(novoProduto).subscribe(() => {
      this.carregarProdutos();
    });
  }

  // Editar produto
  editarProduto(produtoEditado: Produto): void {
    this.produtoService.editarProduto(produtoEditado).subscribe(() => {
      this.carregarProdutos();
    });
  }

  // Excluir produto
  excluirProduto(id: number): void {
    this.produtoService.excluirProduto(id).subscribe(() => {
      this.carregarProdutos();
    });
  }
}
